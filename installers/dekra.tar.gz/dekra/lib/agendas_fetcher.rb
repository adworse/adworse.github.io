# frozen_string_literal: true

require_relative 'agenda_fetcher'

class AgendasFetcher
  def initialize(**options)
    @options = options
  end

  def fetch
    Dir[__dir__ + '/../json/appointments/*.json'].each { |f| File.delete f }
    Parallel.each(
      list,
      in_processes: @options[:threads],
      progress: { title: 'Done:', format: '%t %c/%C| %B%a' },
      &method(:fetch_link)
    )
    self
  end

  def fetch_link(item)
    WatirPool.perform(proxies[Parallel.worker_number]) do |browser|
      AgendaFetcher.new(browser, *item).fetch.save
      sleep(rand * 2 + 1)
    end
  rescue Net::ReadTimeout
    # puts e.inspect
    puts "Net::ReadTimeout. If you're getting many of this, try to reduce number of threads."
    retry
  end

  def proxies
    return {} unless @options[:proxies]
    @proxies ||= Hash.new { |h, n| h[n] = PROXIES[n % PROXIES.count] }
  end

  def list
    centers = JSON.parse File.read(__dir__ + '/../centers.json')
    %w[Essence Gazole].map { |fuel|
      centers.map { |center|
        [OpenStruct.new(center), fuel]
      }
    }.reduce(&:+)
  end
end

