# frozen_string_literal: true

BASEURL = 'https://www.dekra-norisko.fr'

# Fetches single agenda set
class AgendaFetcher
  def initialize(browser, center, energy)
    @browser = browser
    @center = center
    @energy = energy
  end

  def fetch
    setup_cookies
    wait_for_load
    @agenda = fetch_agenda || (raise NoAgenda)
    self
  rescue NoAgenda
    sleep 60
    retry
  rescue PageNotLoaded, WalkthroughError, UnexpectedError => e
    @agenda = { error: e.message }
    self
  end

  def save
    @agenda[:phone] = center.phone
    File.write path, @agenda.to_json
  end

  def path
    "#{__dir__}/../json/appointments/#{center.agreement}.#{energy}.json"
  end

  def exist?
    File.exist?(path)
  end

  private

  attr_accessor :browser, :center, :energy

  def url
    BASEURL + center.href
  end

  def setup_cookies
    @browser.goto url
    update_center
    press(:span, class: 'label', text: 'Voiture')
    press(:span, class: 'label', text: energy)
    press(:button, id: 'take-rdv')
  rescue PageNotLoaded
    if (counter ||= 0) < 4
      counter += 1
      retry
    end
  end

  def update_center
    center.phone = @browser.a(class: 'hide-phone-number')&.href&.tr('tel:', '')
  rescue Watir::Exception::UnknownObjectException
    center.phone = "Can't find the phone"
    @browser.screenshot.save("#{__dir__}/../json/png/#{center.agreement}.png")
  end

  def wait_for_load
    begin
      @browser.div(class: 'sk-loader').wait_while_present
    rescue Watir::Wait::TimeoutError
      counter ||= 0
      counter += 1
      retry unless counter < 3
    end
    @browser
  end

  def fetch_agenda
    date = (Date.today + 1).strftime '%d/%m/%Y'
    @browser.goto(
      "https://www.dekra-norisko.fr/tunnel/get-agenda?date=#{date}"
    )
    JSON.parse(@browser.text).first
  rescue JSON::ParserError
    raise NoAgenda
  end

  def press(what, **selectors)
    button = @browser.send(what, **selectors)
    button.enabled? || raise(WalkthroughError, "Button '#{button.text}' not enabled")
    @browser.div(id: 'btn-valid').style.include?('none;') &&
      raise(WalkthroughError, 'No online schedule, phone only')
    @browser.execute_script('arguments[0].scrollIntoView();', button)
    @browser.execute_script('arguments[0].click();', button)
  rescue Watir::Exception::UnknownObjectException
    raise PageNotLoaded if @browser.title.empty? # still not loaded, will handle on upper lavel
    raise WalkthroughError, "No centre page at #{url}, redirected to #{@browser.url}" if @browser.url != url
    raise WalkthroughError, 'No online schedule, phone only' if @browser.a(class: 'phone-big').present?
    raise WalkthroughError, 'No Voiture available' unless @browser.span(class: 'label', text: 'Voiture').exists?
    raise UnexpectedError
  end
end
NoAgenda = Class.new StandardError
PageNotLoaded = Class.new StandardError
WalkthroughError = Class.new StandardError
UnexpectedError = Class.new StandardError
