# frozen_string_literal: true

# browser creation tool
module WatirPool
  require 'watir'

  SWITCHES =
    %w[
      --ignore-certificate-errors
      --disable-translate
      --disable-notifications
      --disable-infobars
      --disable-gpu
      --headless
    ].freeze

  class << self
    def perform(proxy)
      retries = 0

      @browser ||= create_browser proxy
      yield(@browser)
    rescue Net::ReadTimeout, ArgumentError
      @browser.close
      @browser = nil
      retry if (retries += 1) < 4
    end

    private

    def switches(proxy)
      return SWITCHES unless proxy
      SWITCHES + %W[--proxy-server=#{proxy}]
    end

    def create_browser(proxy)
      Watir::Browser.new(:chrome, switches: switches(proxy)).tap { |b|
        b.driver.manage.window.resize_to(1200, 701)
      }
    end
  end
end
