# frozen_string_literal: true

# Class methods - appointments parser. Instance is single timeslot
class Hour
  def initialize(hour, props)
    @data = hour.merge(props).reject { |_, v| v.to_s.empty? }
  end

  def to_a
    [
      @data[:agreement],
      @data[:fuel],
      @data[:date],
      @data[:heure],
      @data[:vendu].to_bool,
      @data[:prix_ref],
      @data[:prix_promo],
      @data[:percent_promo],
      @data[:date_promo].to_bool,
      @data[:complet_day].to_bool,
      @data[:online],
      Time.now, nil
    ]
  end

  def to_csv
    to_a.to_csv
  end

  def price
    price = @data[:prix_promo] || @data[:prix_ref]
    price&.tr(',', '.')&.to_f
  end

  def keep?(under, over)
    return false unless price
    under ||= -Float::INFINITY
    over ||= Float::INFINITY
    if under < over # range
      (under..over).cover?(price)
    else # two extremes
      price < over || price > under
    end
  end

  def self.from_days(data, **opts)
    props = {
      agreement: data[:agreement],
      fuel: data[:fuel],
      online: data[:online]
    }
    data[:agenda].flat_map { |day|
      from_day day, props
    }.select { |hour| hour.keep?(opts[:under], opts[:over]) }
  end

  def self.from_day(day, props)
    props[:date] = day[:date_agenda]
    props[:date_promo] = day[:date_promo]
    props[:complet_day] = day[:complet_day]
    day[:liste_heure].map { |hour|
      Hour.new hour, props
    }
  end
end

# {error: "Something"}.to_csv
class Error < Hour
  def initialize(data)
    @data = data
  end

  def to_a
    [
      @data[:agreement],
      @data[:fuel],
      [nil] * 8,
      Time.now,
      @data[:error]
    ].flatten
  end
end

# Achtung! Monkey-patched here
class Integer
  def to_bool
    [false, true][self]
  end
end
