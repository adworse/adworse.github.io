# frozen_string_literal: true

require 'parallel'
require_relative 'center_fetcher'

STORAGE = "#{__dir__}/../centers.json"
DEPARTMENTS = File.read(__dir__ + '/../data/departments.csv').split("\n")
TMP = "#{__dir__}/../json/centers/tmp/"

# runs bunch of CenterFetchers
class CentersFetcher
  def initialize(**options)
    @options = options
  end

  def fetch
    Dir[TMP + '*.json'].each { |f| File.delete f }
    Parallel.each(
      links,
      in_processes: @options[:threads],
      progress: { title: 'Done:', format: '%t %c/%C| %B%a' },
      &method(:fetch_link)
    )
    self
  end

  def save(path = STORAGE)
    results = Dir["#{TMP}*.json"]
              .flat_map { |file| JSON.parse File.read(file) }.uniq

    results.each do |center|
      center['href'].gsub!('https:/', '')
    end

    File.write path, results.to_json
  end

  private

  def fetch_link(link)
    WatirPool.perform(proxies[Parallel.worker_number]) do |browser|
      CenterFetcher.new(browser, link).fetch.save
      sleep(rand * 2 + 1)
    end
  rescue => e # Net::ReadTimeout
    puts e.inspect
    # puts "Net::ReadTimeout. If you're getting many of this, try to reduce number of threads."
    retry
  end

  def proxies
    return {} unless @options[:proxies]
    @proxies ||= Hash.new { |h, n| h[n] = PROXIES[n % PROXIES.count] }
  end

  def links
    dep = @options[:department]
    return DEPARTMENTS unless dep
    @links ||= DEPARTMENTS.select { |link| link.end_with?('%02d' % dep) }
  end
end

