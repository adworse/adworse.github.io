# frozen_string_literal: true

require 'nokogiri'
require 'ruby-progressbar'
require 'csv'
require 'json'
require_relative 'watir_pool'

# fetches set of centers from single department link
class CenterFetcher
  INSEE = CSV.read(__dir__ + '/../data/insee.csv')

  def initialize(browser, link)
    @b = browser
    @link = link
  end

  def path
    "#{TMP}#{@link.split('/').last}.json"
  end

  def save
    File.write path, @centers.to_json
  end

  def get_insee(center)
    place =
      center[:place]
      .gsub(/'|-/, ' ').gsub('SAINT ', 'ST ')
      .gsub('SAINTE ', 'STE ').gsub(/ \((\w| )\)/, '')
    INSEE.select { |row|
      row[2] == center[:zip] &&
        row[1] == place
    }.first&.first
  end

  def wait_for_load(b)
    begin
      b.div(class: 'sk-loader').wait_while_present
    rescue Watir::Wait::TimeoutError
      counter ||= 0
      counter += 1
      retry unless counter < 4
    end
    b
  end

  def fetch
    @b.goto @link
    wait_for_load @b
    @centers = parse_html(@b.html)
    self
  end

  def parse_html(html)
    Nokogiri::HTML(html).css('li.cen-row').map { |li|
      {
        zip: li['data-codepostal'],
        place: li['data-ville'],
        agreement: li['data-agr'],
        name: li['data-titre'],
        address: li.at_css('span.g-adress').text,
        href: li.at_css('a.jq-cta-info')[:href],
        online: li.at_css('i.pay-ico-cb') ? true : false
      }.tap { |h| h[:insee] = get_insee(h) }}
  end
end