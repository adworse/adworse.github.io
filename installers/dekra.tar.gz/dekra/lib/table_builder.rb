# frozen_string_literal: true

require 'time'
require_relative 'hour'

# builds the final table
class TableBuilder
  TIMESTAMP = Time.now.strftime('%Y.%m.%d-%H.%M.%S')
  CENT_HEADERS = "Agreement Code,INSEE,Title,ZIP,City,Street Address,Phone,URL,Online payments?\n"
  APP_HEADERS = "Agreement Code,Engine Type,Date,Time,Booked?,Base Price,New Price,\
Promo Percent,Vente Flash,Complet Day,Online payments?,Parsed at,error\n"

  def initialize(**options)
    @options = options
    @centers = JSON.parse(File.read(__dir__ + '/../centers.json'), symbolize_names: true)
  end

  def online?(agreement)
    @online ||= @centers.map { |c| [c[:agreement], c[:online]] }.to_h
    @online[agreement]
  end

  def data(filename)
    agenda = JSON.parse(File.read(filename), symbolize_names: true)
    agenda[:agreement], agenda[:fuel] = filename.split(%r{[/.]})[-3..-2]
    agenda[:online] = online? agenda[:agreement]
    agenda
  end

  def json2a(filename)
    agenda = data(filename)
    rows = agenda[:error] ? [Error.new(agenda)] : Hour.from_days(agenda, @options)
    rows.map(&:to_a)
  end

  def table
    Dir.glob(__dir__ + '/../json/appointments/*.json').flat_map { |filename| json2a filename }.compact
  end

  def sort
    full, empty = table.partition { |row| row[2] }
    full.sort_by { |r| [r[0], r[1], Date.parse(r[2]), Time.parse(r[3])] } + empty.sort
  end

  def apps2csv
    csv = APP_HEADERS + sort.map(&:to_csv).join('')
    File.write "#{__dir__}/../apps-#{TIMESTAMP}.csv", csv
  end

  def enrich_centers
    @centers.map { |center|
      filename = Dir.glob(__dir__ + '/../json/appointments/*.json').detect { |file| file.match?(center[:agreement]) }
      center[:phone] = JSON.parse(File.read(filename), symbolize_names: true)[:phone]
      center
    }
  end

  def centers2csv
    @centers = enrich_centers
    csv = @centers.map { |center|
      [
        center[:agreement],
        center[:insee],
        center[:name],
        center[:zip],
        center[:place],
        center[:address],
        center[:phone],
        BASEURL + center[:href],
        center[:online]
      ].to_csv
    }.unshift(CENT_HEADERS)
    File.write "#{__dir__}/../centers-#{TIMESTAMP}.csv", csv*''
    File.delete "#{__dir__}/../centers.json"
  end
end
