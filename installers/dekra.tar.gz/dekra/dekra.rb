#!/usr/bin/env ruby
# frozen_string_literal: true

require 'fileutils'
require 'slop'
require_relative 'lib/centers_fetcher'
require_relative 'lib/agendas_fetcher'
require_relative 'lib/table_builder'

opts = Slop.parse { |o|
  o.integer '-t', '--threads', 'number of threads', default: 1
  o.integer '-d', '--department', 'one department only'
  o.integer '-u', '--under', 'only appointments with the price less than'
  o.integer '-o', '--over', 'only appointments with the price greater than'
  o.bool '-p', '--proxies', 'scrape with proxies'
}

PROXIES = File.read(__dir__ + '/data/proxies.csv').split("\n").shuffle if opts[:proxies]

%w[
  json/centers/tmp
  json/png
  json/appointments
].each do |path|
  FileUtils.mkdir_p "#{__dir__}/#{path}"
end


`killall -q -9 chromedriver`
`killall -q -9 chrome`

puts 'Fetching centres:'
CentersFetcher.new(opts.to_h).fetch.save
puts 'Getting appointments...'
AgendasFetcher.new(opts.to_h).fetch

puts 'Joining and filtering...'
TableBuilder.new(opts.to_h).apps2csv
TableBuilder.new(opts.to_h).centers2csv
print 'Compressing... '
`gzip -9 #{__dir__}/*.csv`
puts 'Done'
