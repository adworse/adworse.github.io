#!/usr/bin/env ruby
# frozen_string_literal: true

require 'json'
require 'csv'
require_relative 'lib/web_archive'
require_relative 'lib/recent'

def try
  counter = 0
  begin
    yield
  rescue Net::HTTP::Persistent::Error, Net::HTTPGatewayTimeOut,
         Net::HTTPServiceUnavailable, Errno::ECONNREFUSED,
         NoMethodError, Mechanize::ResponseCodeError => e
    puts e
    sleep 5
    counter += 1
    retry if counter < 5
  end
end

ARGV.each do |username|
  puts "Getting and parsing @#{username} from Web Archive "
  try do
    File.write "#{__dir__}/#{username}.wayback.csv", WebArchive.new(username).download.to_csv
  end

  puts "Getting and parsing @#{username}'s articles"
  try do
    File.write "#{__dir__}/#{username}.articles.csv", Recent.new(username).articles
  end

  puts "Getting and parsing @#{username}'s responses"
  try do
    File.write "#{__dir__}/#{username}.responses.csv", Recent.new(username).responses
  end
end
