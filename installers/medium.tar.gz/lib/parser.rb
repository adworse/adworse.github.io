# frozen_string_literal: true

class Parser
  def initialize(path)
    @doc = Nokogiri::HTML File.read(path)
    @id_and_time = path.split(%r{/|\.})[-3..-2]
  end

  def parse
    @id_and_time + (parse_1 || parse_2) << doc.at('p.hero-description').text
  end

  def parse_1
    %w[following followers].map { |what|
      (
        doc.at("button[data-action-value=#{what}]") ||
        doc.at("a.button[data-action-value=#{what}]")
      )[:title].delete('^0-9')
    }
  rescue NoMethodError
  end

  def parse_2
    cdata = doc.css('script').map(&:text).join
    %w["usersFollowedCount": "usersFollowedByCount":].map { |what|
      cdata.scrub.scan(/(#{what})(\d+)/).last.last
    }
  # rescue ArgumentError
  #   puts cdata.inspect
  #   []
  end

  private

  attr_reader :doc
end

# list.map {|file| begin; Parser.new(file).parse; rescue NoMethodError; end}
