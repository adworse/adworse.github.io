# frozen_string_literal: true

class Recent
  UNAVAILABLE = { url: 'This story is unavailable.', claps: nil, resp: nil }.freeze

  def initialize(username)
    @username = username
    @users = {}
  end

  def json(to, source)
    to = ('&to=' + to) if to
    Mechanize.new.get("https://medium.com/_/api/users/#{id}/profile/stream?limit=8#{to}&source=#{source}&page=1")
             .body.gsub('])}while(1);</x>', '')
  end

  def batch(json)
    json = JSON.parse json, symbolize_names: true
    return [nil, nil, nil] if json[:payload][:streamItems].empty?
    [
      json[:payload][:references][:Post],
      json[:payload][:references][:User],
      json[:payload][:paging]&.[](:next)&.[](:to)
    ]
  end

  # :latest or :responses
  def parse(source)
    keeper = {}
    to = nil
    loop do
      loaded, new_users, new_to = batch json(to, source)
      to = new_to
      keeper.merge! loaded if loaded
      users.merge! new_users if new_users
      break unless to
      # puts to
    end
    keeper
  end

  def articles
    parse(:latest).values
                  .map { |data|
                    article(data).values.to_csv
                  }.join
  end

  def article(data)
    {
      username: username,
      url: "https://medium.com/@#{username}/#{data[:slug]}-#{data[:id]}",
      title: data[:title],
      date: Time.at(data[:createdAt].to_s[0, 10].to_i).utc,
      reading_time: data[:virtuals][:readingTime],
      claps: data[:virtuals][:totalClapCount],
      comments_amount: data[:virtuals][:responsesCreatedCount]
    }
  end

  def responses
    resp, @origins =
      parse(:responses).partition { |_, post| post[:creatorId] == id }
                       .map(&:to_h)
    resp.values
        .map { |data|
          response(data).values.to_csv
        }.join
  end

  def response(data)
    {
      username: username,
      response_url: "https://medium.com/@#{username}/#{data[:slug]}-#{data[:id]}",
      resp_reading_time: data[:virtuals][:readingTime],
      response_claps: data[:virtuals][:totalClapCount],
      responses_on_response_count: data[:virtuals][:responsesCreatedCount]
    }.merge! origin(data[:inResponseToPostId])
  end

  def origin(origin_id)
    data = @origins[origin_id.to_sym] || (return UNAVAILABLE)
    user = users[
      data[:creatorId].to_sym
    ][:username]
    {
      origin_url: "https://medium.com/@#{user}/#{data[:slug]}-#{data[:id]}",
      origin_claps: data[:virtuals][:totalClapCount],
      responses_on_origin_count: data[:virtuals][:responsesCreatedCount]
    }
  end

  private

  def id
    return @userid if @userid
    doc = Nokogiri::HTML Mechanize.new.get("https://medium.com/@#{username}").body
    @userid = doc.at_css('span.followState.js-followState')['data-user-id']
      # doc.css("a[href='https://medium.com/@#{username}']")
      #    .map { |a| a['data-user-id'] }
      #    .compact
      #    .first
  end

  attr_reader :username, :users
end
