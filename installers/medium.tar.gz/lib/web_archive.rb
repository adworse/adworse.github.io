# frozen_string_literal: true

require 'parallel'
require 'mechanize'
require 'csv'
require_relative 'parser'

class WebArchive
  USER_AGENT =
    "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.1 (KHTML, like Gecko)\
    Chrome/13.0.782.41 Safari/535.1"

  def initialize(username)
    @username = username
    dir = "#{__dir__}/../html"
    `mkdir #{dir}` unless File.exist?(dir)
  end

  def download
    Parallel.each(list, in_threads: 8) do |ary|
      filename = "#{__dir__}/../html/#{@username}.#{ary.first}.html"
      next if File.exist? filename
      mech ||= Mechanize.new.tap { |m| m.user_agent = USER_AGENT }
      url = "http://web.archive.org/web/#{ary.first}/#{ary.last}"
      begin
        File.write filename, mech.get(url).body
        print '.'
      rescue Net::HTTP::Persistent::Error, Errno::ECONNREFUSED
        sleep 10
        retry
      rescue Mechanize::ResponseCodeError => e
        # puts e.response_code.inspect
        if e.response_code == '504'
          sleep 20
          retry
        else
          puts e
        end
      end
    end
    puts
    self
  end

  def to_csv
    files = Dir.glob("#{__dir__}/../html/#{@username}.*.html").sort
    Parallel.map(files, in_threads: 8) { |file|
      begin
        Parser.new(file).parse.to_csv
      rescue NoMethodError
      end
    }.compact.join
  end


  private

  attr_reader :username

  def list
    @list ||=
      Mechanize.new
               .tap { |m| m.user_agent = USER_AGENT }
               .get("http://web.archive.org/cdx/search/xd?url=medium.com/@#{username}")
               .body
               .split("\n")
               .map(&:split)
               .select { |line| line[4] == '200' }
               .map { |line| line[1..2] }
  end
end
